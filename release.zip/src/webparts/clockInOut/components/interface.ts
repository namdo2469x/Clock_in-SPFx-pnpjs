export interface IClock {
    Clock_in: string
    Clock_out: string
    Email: string
    Fullname: string
  }