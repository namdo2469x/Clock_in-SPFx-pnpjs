/* eslint-disable @typescript-eslint/no-use-before-define */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable dot-notation */
/* eslint-disable no-var */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
import { SPFI } from '@pnp/sp/fi';
import * as React from 'react';
import { getSP } from '../../../service/pnpjsconfig';
import styles from './ClockInOut.module.scss';
import { IClockInOutProps } from './IClockInOutProps';
import { IClock } from './interface';
import * as dayjs from 'dayjs'
import { Modal } from 'office-ui-fabric-react';

const ClockInOut = (props: IClockInOutProps) => {
  const LIST_NAME = 'Clock'
  let _sp: SPFI = getSP(props.context);

  const [email, setEmail] = React.useState('')
  const [name, setName] = React.useState('')
  const [clock_in, setClock_In] = React.useState('')
  const [clock_out, setClock_Out] = React.useState('')
  const [clockList, setClockList] = React.useState<IClock[]>([])
  const [open, setOpen] = React.useState(false)


  const getCurrentUser = async () => {
    const user = await _sp.web.currentUser()
    setEmail(user.Email)
    setName(user.Title)
  }

  const toggleModal = () => {
    if (open === false) {
      setOpen(true)
    } else setOpen(false)
    console.log(open)
  }

  const getListItem = async () => {
    const items = _sp.web.lists.getByTitle(LIST_NAME).items.select().orderBy('ID', false)();
    setClockList((await items).map((item: any) => {
      return {
        Email: item.Title,
        Fullname: item.Fullname,
        Clock_in: item.ClockIn,
        Clock_out: item.ClockOut
      }
    }))
  }

  const checkUserTime = async () => {
    const items = _sp.web.lists.getByTitle(LIST_NAME).items.select().filter(`Title eq '${email}'`).getAll();
    console.log("userlists", items)
    var output1: string[] = [];
    var output2: string[] = [];
    for (var i = 0; i < (await items).length; ++i) {
      output1 = (await items)[i]['ClockIn']
      output2 = (await items)[i]['ClockOut']
    }
    

  }

  const handleClockIn = async () => {
    await _sp.web.lists.getByTitle(LIST_NAME).items.add({
      Title: email,
      Fullname: name,
      ClockIn: dayjs(Date().toLocaleString()).format('HH:mm:ss'),
      ClockOut: ''
    })
    checkUserTime()
  }

  const handleClockOut = async () => {
    const lastestItem: any[] = await _sp.web.lists.getByTitle(LIST_NAME).items.select().top(1).orderBy('ID', false)();
    await _sp.web.lists.getByTitle(LIST_NAME).items.getById(lastestItem[0].Id).update({
      ClockOut: dayjs(Date().toLocaleString()).format('HH:mm:ss')
    })
    reRender()
  }

  const reRender = () => {
    getListItem()
  }

  React.useEffect(() => {
    getCurrentUser()
    getListItem()
    checkUserTime()
  }, [email])

  return (
    <div className={styles.container}>
      <div className={styles['container-lab']}>
        <div className={styles['input-item']}>
          <label>Email: </label>
          <input type="text" value={email} disabled />
        </div>
        <div className={styles['input-item']}>
          <label>Full Name: </label>
          <input type="text" value={name} disabled />
        </div>
        <div className={styles['input-item']}>
          <label>Current Time: </label>
          <input type="text" value={dayjs(Date().toLocaleString()).format('DD/MM/YYYY - HH:mm:ss')} disabled />
        </div>
      </div>
      {(clock_in === null || clock_out !== null) ? (<button onClick={handleClockIn}>CLOCK IN</button>) : (<button onClick={handleClockOut}>CLOCK OUT</button>)}
      <h1>Clock Table</h1>
      <table>
        <tr className={styles.thead}>
          <th>ID</th>
          <th>Email</th>
          <th>Full Name</th>
          <th>Time</th>
        </tr>
        {clockList.map((o: IClock, index: number) => {
          if (index % 2 === 0) {
            return (
              <tr key={index} className={styles['table-color']} onClick={toggleModal}>
                <td>{index + 1}</td>
                <td>{o.Email}</td>
                <td>{o.Fullname}</td>
                <td>{o.Clock_in} - {o.Clock_out}</td>
              </tr>
            )
          }
          if (index % 2 !== 0) {
            return (
              <tr key={index} onClick={toggleModal}>
                <td>{index + 1}</td>
                <td>{o.Email}</td>
                <td>{o.Fullname}</td>
                <td>{o.Clock_in} - {o.Clock_out}</td>
              </tr>
            )
          }
          <Modal
            onDismiss={toggleModal}
            isOpen={open}
            >
              <p>Email: {o.Email}</p>
              <p>Full Name: {o.Fullname}</p>
              <p>Clock In: {o.Clock_in}</p>
              <p>Clock Out: {o.Clock_out}</p>
          </Modal>
        })}
      </table>
    </div>
  )
}

export default ClockInOut