/* tslint:disable */
require("./ClockInOut.module.css");
const styles = {
  container: 'container_26a39334',
  'container-lab': 'container-lab_26a39334',
  'input-item': 'input-item_26a39334',
  thead: 'thead_26a39334',
  'table-color': 'table-color_26a39334'
};

export default styles;
/* tslint:enable */