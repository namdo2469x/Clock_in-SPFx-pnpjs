import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/batching";
import "@pnp/sp/site-users";
import "@pnp/sp/items";
import "@pnp/sp/items/get-all";
export declare const getSP: (context?: WebPartContext) => SPFI;
//# sourceMappingURL=pnpjsconfig.d.ts.map