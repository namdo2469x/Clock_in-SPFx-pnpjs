/// <reference types="react" />
import { IClockInOutProps } from './IClockInOutProps';
declare const ClockInOut: (props: IClockInOutProps) => JSX.Element;
export default ClockInOut;
//# sourceMappingURL=ClockInOut.d.ts.map