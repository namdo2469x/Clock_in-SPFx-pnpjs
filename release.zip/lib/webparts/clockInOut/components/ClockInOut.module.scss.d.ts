declare const styles: {
    container: string;
    'container-lab': string;
    'input-item': string;
    thead: string;
    'table-color': string;
};
export default styles;
//# sourceMappingURL=ClockInOut.module.scss.d.ts.map